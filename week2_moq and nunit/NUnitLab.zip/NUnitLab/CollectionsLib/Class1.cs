﻿namespace CollectionsLib;

public class Class1
{

}
