﻿namespace ConverterLib;

public class Class1
{

}
