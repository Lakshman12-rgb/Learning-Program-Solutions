﻿namespace FourSeasonsLib;

public class Class1
{

}
