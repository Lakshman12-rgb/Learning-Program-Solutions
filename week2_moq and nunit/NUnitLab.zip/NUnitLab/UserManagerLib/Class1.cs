﻿namespace UserManagerLib;

public class Class1
{

}
