﻿namespace AccountsManagerLib;

public class Class1
{

}
