﻿namespace LeapYearCalculatorLib;

public class Class1
{

}
