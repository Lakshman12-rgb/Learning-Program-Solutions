﻿namespace CalcLibrary;

public class Class1
{

}
